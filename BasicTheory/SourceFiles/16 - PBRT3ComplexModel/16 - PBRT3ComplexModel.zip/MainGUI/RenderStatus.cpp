#include "RenderStatus.h"

renderStatus m_RenderStatus;
